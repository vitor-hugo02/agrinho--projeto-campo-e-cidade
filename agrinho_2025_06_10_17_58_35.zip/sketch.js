let campocidade;

let xjogador = [470, 370,200,170 ];
let yjogador = [200, 150, 125, 150];
let jogador = ["🫘", "🫘", "🫘", "🫘"];
let quantidade = jogador.length;


function preload(){
   campocidade = loadImage ('campocidade.jpg');

}

function setup() {
  createCanvas(600, 800);
 
  
}

function draw() {
  background(220);
  image (campocidade, 0,0,600,800)

  
  desenhaJogadores();
  desenhaLinhaChegada();
  verificaVencedor();
}
function desenhaJogadores() {
  textSize(40);
  for (let i = 0; i < quantidade; i++) {
    text(jogador[i], xjogador[i], xjogador[i]);
  }

  //text(jogador[1], xjogador[1], xjogador[1]);
  // text(jogador[2], xjogador[2], xjogador[2]);
}

  function desenhaLinhaChegada() {
  fill("white");
  rect(400, 600, 10);
  fill("rgb(79,218,34)");
 

}
function verificaVencedor() {
  for (let i = 0; i < quantidade; i++) {
    if (xjogador[i] > 350) {
      fill ("#F0DA12");
      text(jogador[i] + "viva a conexão campo cidade!!", 50, 200, 300);
      noLoop();
    }o pais mais lindo do mundo
  }
}

let teclas = ["a", "s", "d", "f"];
function keyReleased() {
  for (let i = 0; i < quantidade; i++) {
    if (key === teclas[i]) {
      xjogador[i] += random(20);
    }
  }
}